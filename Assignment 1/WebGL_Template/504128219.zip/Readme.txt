Readme
Lawrence Ouyang
CS174A
Assignment 1

Requirements:
a. Each component is built hierachical, and objects with multiple components are built in their own routines.

b. Ground exists.

c. Tree is made of eight rectangular prisms with a sphere on top.

d. Tree sways from left to right.

e. Trunk rotation rotates around the bottom face.

f. Wasp is along the x axis and all components are animated.

g. Wasp orbits flower, with its direction tangent to orbit.

h. Wasp hovers up and down.

i. Wasp and tree joints are proper compared to diagrams and reference videos.